// Component will be registered in the main components index
export { default as DatasetUploader } from './dataset-uploader.vue'
