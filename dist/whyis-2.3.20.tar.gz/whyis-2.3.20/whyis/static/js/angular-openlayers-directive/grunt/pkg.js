'use strict';

module.exports = function (grunt, options) {
    return grunt.file.readJSON('package.json');
};
