angular-openlayers-directive changelog
---

Hi, we've fully automated our release. Even the changelog which you can find under the [release](https://github.com/tombatossals/angular-openlayers-directive/releases) tab of our GitHub repo.

You can automate your library as well. It's easy: [Release your libs like a pro](http://juristr.com/blog/2015/10/release-like-a-pro/)
