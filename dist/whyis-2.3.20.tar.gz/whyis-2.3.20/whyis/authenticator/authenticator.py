class Authenticator:
    def authenticate(self, request, datastore, config):
        pass
