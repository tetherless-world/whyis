DATA_EXTENSIONS = {
    "rdf": "application/rdf+xml",
    "jsonld": "application/ld+json",
    "json": "application/json",
    "ttl": "text/turtle",
    "trig": "application/trig",
    "turtle": "text/turtle",
    "owl": "application/rdf+xml",
    "nq": "application/n-quads",
    "nt": "application/n-triples",
    "html": "text/html"
}
