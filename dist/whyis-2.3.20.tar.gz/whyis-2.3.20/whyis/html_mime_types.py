HTML_MIME_TYPES = {'application/xhtml','text/html', 'application/xhtml+xml'}
