from whyis import autonomic
from rdflib import *
from slugify import slugify
from whyis import nanopub

from whyis.namespace import sioc_types, sioc, sio, dc, prov, whyis
