A directory for serving static images.
