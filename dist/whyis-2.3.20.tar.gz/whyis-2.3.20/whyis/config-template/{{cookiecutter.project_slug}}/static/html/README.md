A directory for static HTML files, such as Angular.js templates.
