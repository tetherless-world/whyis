Directory for fuseki jar files to be loaded at build time.
