from flask import Blueprint

tableview_blueprint = Blueprint("tableview_blueprint", __name__)