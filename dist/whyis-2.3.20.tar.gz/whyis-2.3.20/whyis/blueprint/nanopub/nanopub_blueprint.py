from flask import Blueprint

nanopub_blueprint = Blueprint("nanopub_blueprint", __name__)
