from flask import Blueprint

sparql_blueprint = Blueprint("sparql_blueprint", __name__)
