from flask import Blueprint

entity_blueprint = Blueprint("entity", __name__)
